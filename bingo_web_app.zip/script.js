const board = document.getElementById("board");

for (let i = 0; i < 25; i++) {
  const number = Math.floor(Math.random() * 75) + 1;
  const cell = document.createElement("div");
  cell.className = "cell";
  cell.textContent = number;
  cell.onclick = () => {
    cell.classList.toggle("selected");
  };
  board.appendChild(cell);
}
